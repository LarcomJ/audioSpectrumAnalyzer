/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include    <led_object.h>
#include    "cytypes.h"

#ifndef DISPLAY
#define DISPLAY
    
    // define variables

    // prototype functions
    void update_buffer(uint8 *buff, led array[], char len );
    
#endif

/* [] END OF FILE */
